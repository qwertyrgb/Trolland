#Next variable : 
#currentAction=4 (global index of Desc1_4_books="You see three heavy books")
#Next[currentAction]=AskP1_books (variable the program should print next)

Next=['Desc1_1_room', #boot
      'AskP1_room', #1
      'Desc1_3_note', #2
      'AskP1_downstairs', #3
      'AskP1_books', #4
      'AskP1_books', #5
      'AskP1_books', #6
      'AskP1_books', #7
      'Desc1_9_boom', #8
      'AskP1_boom', #9
      'AskP1_room', #10
      'AskP1_downstairs', #11
      'AskP1_backOutside', #12
      'OSay1_14_momScream', #13
      'Desc1_15_isThatSooo', #14
      'PSay1_16_mom', #15
      'OSay1_17_dontCome', #16
      'Desc1_18_momDead', #17
      'OSay1_19_trollSpeak', #18
      'Desc1_20_chased', #19
      'AskP1_chased', #20
      'OSay1_23_kamisaGo',#21
      'OSay1_23_kamisaGo',#22
      'Desc1_24_Insinct', #23
      'AskP1_weaponChoice', #24
      'SetV1_34_slash', #25
      'SetV1_35_flame', #26
      'SetV1_35_flame',#27
      'Desc1_29_preFight', #28
      'Cmbt1_30_troll', #29
      'Desc1_31_hide', #30
      'Desc1_32_wait', #31
      'PSay1_33_alone', #32
      'EndG1_demoOver', #33
      'OSay1_28_kamisaFight', #34
      'OSay1_28_kamisaFight' #35
     ]

